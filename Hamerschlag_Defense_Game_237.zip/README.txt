Hamerschlag_Defense
===================
Jack Paparian, Ben Charas, Russell Tucker

Hamerschlag Defense is a tower defense game made for CMU's 15-237 class. 

In it you, as a member of the Carnegie Mellon faculty, are tasked with "raining knowledge" 
upon the student body -- comprised of charicactures of various majors -- to prevent them
from abandoning academia to... go outside. 

Using a homework-firing turret mounted atop Hamerschlag, you must prevent endless waves of students from 
crossing the mall to pass you, exit campus, and go into the city. 

At the start of the game, Andrew Carnegie is summoned to help enforce that the students 
"keep their hearts in the work," and he will attempt to autonomously try to prevent the students' passage by firing homework from baker.

Over the course of the game, as you accumulate money from the defeated students' tuitions, you may spend increasing amounts to purchase 
textbooks (for $75k per stack) that slow the students' progression (like a breakable road block). 

For up to $400k more, you may summon a total of 3 (including the first) apparitions of Andrew Carnegie to offer an increasingly effective
 defense against the student body. You may bind the spirit of Andrew Carnegie by clicking one of the purple boxes on either side of the original Andrew Carnegie.
 
 Happy playing!

Bibliography
============

Book image:
http://3.bp.blogspot.com/-APoXEqKQFjo/TrlJWz1P7pI/AAAAAAAAA5M/61e53Id4CGs/s1600/books-stack.jpg

Crumpled paper ball image:
http://thumbs.dreamstime.com/thumblarge_572/1294396647I4aj6h.jpg

Grass image:
http://free-textures.got3d.com/natural/free-grass-textures/images/free-grass-texture-013.jpg

Hamerschlag front image:
http://www.facebook.com/l.php?u=http%3A%2F%2Fciviccenter.cc%2Fsite%2Fwp-content%2Fuploads%2F2012%2F03%2FMEAtCarnegieMellon1-650x487.jpg&h=0AQFTVhR-

Andrew Carnegie image:
http://www.biography.com/imported/images/Biography/Images/Profiles/C/Andrew-Carnegie-9238756-1-402.jpg

Carnegie Mellon seal image:
http://upload.wikimedia.org/wikipedia/en/b/bb/Carnegie_Mellon_University_seal.svg

Andrew Carnegie open mouth image:
http://thumb11.shutterstock.com/thumb_small/451498/451498,1316446370,5/stock-photo-illustration-uvula-in-the-throat-close-up-84936112.jpg

No symbol image:
http://marmysz.files.wordpress.com/2012/10/nosymbol.gif

Sky image:
http://www.allabouthappylife.com/wallpaper/dual_monitor/sky/beautiful_sky-dsc01468-dws.jpg
